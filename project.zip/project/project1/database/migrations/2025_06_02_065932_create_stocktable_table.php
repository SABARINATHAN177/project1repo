<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateStocktableTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('stocktable', function (Blueprint $table) 
        {   $table->date('Updated Date');
            $table->integer('Scissors:');
            $table->integer('razors:');
            $table->integer('clippers:');
            $table->integer('trimmers:');
            $table->integer('Hairdryers:');
            $table->integer('curling irons:');
            $table->integer('straighteners:');
            $table->integer('hot rollers:');
            $table->integer('Facial steamers:');
            $table->integer('LED therapy devices:');
            $table->integer('microdermabrasion machines:');
            $table->integer('Nail clippers');
            $table->integer('cuticle pushers:');
            $table->integer('nail buffers:');
            $table->integer('UV lamps :');
            $table->integer('Styling chairs:');
            $table->integer('shampoo stations:');
            $table->integer('massage beds:');  
            $table->integer('facial tissues:');
            


        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('stocktable');
    }
}
