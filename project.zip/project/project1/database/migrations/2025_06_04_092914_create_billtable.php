<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateBilltable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {Schema::create('billtable', function (Blueprint $table) {
        $table->string('StaffName');  // Removed ':'
        $table->string('ServiceName'); // Removed ':'
        $table->int('Amount');
        // Removed ':'
        
        $table->date('Date');
        $table->time('Time');
    });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('billtable');
    }
}
