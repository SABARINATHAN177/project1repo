<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateEmptableTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        
            Schema::create('emptable', function (Blueprint $table) {
               // $table->id(); // Auto-incrementing primary key
                $table->string('Name');
                $table->integer('Age');
                $table->enum('Gender', ['Male', 'Female', 'Others']);
                $table->integer('Experience');
                $table->string('ContactNo');
                $table->string('EmailId');
                $table->string('Qualification');
                $table->enum('MaritalStatus', ['yes', 'No']);
                $table->string('Address');
                $table->string('State');
                $table->string('City');
                $table->integer('Pincode');
                //$table->timestamps(); // Add timestamps to fix the error
            });
        }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('emptable');
    }
}
