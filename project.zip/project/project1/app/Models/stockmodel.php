<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Carbon\Carbon;

class StockModel extends Model
{
    use HasFactory;

    protected $table = 'stocktable';
   protected $fillable = [
    'updated_date', 'scissors', 'razors', 'clippers', 'trimmers', 'hairdryers',
    'curlingirons', 'straighteners', 'hotrollers', 'facialsteamers', 'ledtherapydevices',
    'microdermabrasionmachines', 'nailclippers', 'cuticlepushers', 'nailbuffers', 'uvlamps',
    'stylingchairs', 'shampoostations', 'massagebeds', 'facialtissues'
];

    public $timestamps = false; // Prevents Laravel from inserting created_at & updated_at

    // Automatically set default value for updated_date if not provided
   
}