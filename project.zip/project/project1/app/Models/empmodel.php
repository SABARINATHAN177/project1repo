<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
class empmodel extends Model
{
    use HasFactory;

    protected $table = 'emptable';
    protected $fillable = ['Name', 'Age', 'Gender', 'Experience', 'ContactNo', 'EmailId', 'Qualification', 'MaritalStatus', 'Address', 'State', 'City', 'Pincode'];
    public $timestamps = false;

}