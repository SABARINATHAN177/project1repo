<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class billmodel extends Model
{
    use HasFactory;
    protected $table = 'billtable';
    protected $fillable=['StaffName','ServiceName','Amount','date','time'];
    public $timestamps = false;
   /* protected $attributes = [
        'ServiceName' => 'General Service', // Default value if missing
    ];*/
    
}
