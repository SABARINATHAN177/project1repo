<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\BillModel;

class BillingPageController extends Controller
{
    public function index()
    {
        return view('billingpage');
    }

    public function store(Request $request)
    {
        $request->validate([
            'ServiceName' => 'required|string',
            'StaffName' => 'required|string',
            'Amount'=>'required|integer',
            'date' => 'required|date',
            'time' => 'required',
        ]);
        BillModel::create([
            'ServiceName' => $request->ServiceName,
            'StaffName' => $request->StaffName,
            'Amount' => $request->Amount,
            'date' => $request->date,
            'time' => $request->time,
            
        ]);
    
        return redirect()->route('billingpage')->with('success', 'Billing record saved successfully!');
   
    }
}