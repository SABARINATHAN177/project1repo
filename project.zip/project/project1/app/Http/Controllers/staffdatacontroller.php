<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\empModel;

class StaffDataController extends Controller
{
    public function index()
    {
        return view('staffdata');
    }

    
    public function show(Request $request)
    {
        $staff = empModel::where('Name', $request->StaffName)->first();
    
        if (!$staff) {
            return redirect()->back()->with('error', 'Staff not found!');
        }
    
        return view('staffdata', compact('staff'));
    }
    
}