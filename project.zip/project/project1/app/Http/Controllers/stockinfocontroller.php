<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\stockModel;

class StockInfoController extends Controller
{
    public function index()
    {
        return view('stockinfo');
    }

    
    
    public function show(Request $request)
{
    $date = $request->input('date');

    $stock = StockModel::where('updated_date', $date)->first();

    if (!$stock) {
        return back()->withErrors(['msg' => 'No stock data found for this date.']);
    }

    return view('stockinfo', compact('stock', 'date'));
}
}