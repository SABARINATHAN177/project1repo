<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\empModel;

class StaffdetailsController extends Controller
{
public function index()
{
    $staffRecords = empModel::all();
    return view('staffdetails', compact('staffRecords'));
}
    
   /*public function store(Request $request)
    {
        $staff = empModel::create([
            $request->validate([
                'Name' => 'required|string|max:255',
        
            
          
            'Age' => $request->Age,
            'Gender' => $request->Gender,
            'Experience' => $request->Experience,
            'ContactNo' => $request->ContactNo,
            'EmailId' => $request->EmailId,
            'Qualification' => $request->Qualification,
            'MaritalStatus' => $request->MaritalStatus,
            'Address' => $request->Address,
            'State' => $request->State,
            'City' => $request->City,
            'Pincode' => $request->Pincode,])
        ]);
    
    
   /* public function store(Request $request)
    {
        $request->validate([
            'Name' => 'required|string|max:255',
            'Age' => 'required|integer|min:18', // Assuming employees must be at least 18
            'Gender' => 'required|in:Male,Female,Others',
            'Experience' => 'required|integer|min:0',
            'ContactNo' => 'required|string|max:15',
            'EmailId' => 'required|email|unique:emptable,EmailId',
            'Qualification' => 'required|string|max:255',
            'MaritalStatus' => 'required|in:yes,No',
            'Address' => 'required|string',
            'State' => 'required|string',
            'City' => 'required|string',
            'Pincode' => 'required|digits:6', // Ensuring it's a valid 6-digit pincode

        ]);
        empmodel::create([
            'Name' => $request->Name,
            'Age' => $request->Age,
            'Gender' => $request->Gender,
            'Experience' => $request->Experience,
            'ContactNo' => $request->ContactNo,
            'EmailId' => $request->EmailId,
            'Qualification' => $request->Qualification,
            'MaritalStatus' => $request->MaritalStatus,
            'Address' => $request->Address,
            'State' => $request->State,
            'StaffName' => $request->StaffName,
            'City' => $request->City,
            'Pincode' => $request->Pincode,]);
        return redirect()->route('staffdetailspage')->with('success', 'Billing record saved successfully!');}
    }
*///public function store(Request $request)

//{
  //  dd($request->all()); // Check if data is properly coming from the form//
//}}
/*public function store(Request $request)
{
    $request->validate([
        'Name' => 'required|string|max:255',
        'Age' => 'required|integer|min:18',
        'Gender' => 'required|in:Male,Female,Others',
        'Experience' => 'required|integer|min:0',
        'ContactNo' => 'required|string|max:15',
        'EmailId' => 'required|email|unique:emptable,EmailId',
        'Qualification' => 'required|string|max:255',
        'MaritalStatus' => 'required|in:yes,No',
        'Address' => 'required|string',
        'State' => 'required|string',
        'City' => 'required|string',
        'Pincode' => 'required|digits:6',
    ]);

    $staff = empModel::create([
        'Name' => $request->Name,
        'Age' => $request->Age,
        'Gender' => $request->Gender,
        'Experience' => $request->Experience,
        'ContactNo' => $request->ContactNo,
        'EmailId' => $request->EmailId,
        'Qualification' => $request->Qualification,
        'MaritalStatus' => $request->MaritalStatus,
        'Address' => $request->Address,
        'State' => $request->State,
        'City' => $request->City,
        'Pincode' => $request->Pincode,
    ]);

    return redirect()->route('staffdetails')->with('success', 'Record saved successfully!');

*/
public function store(Request $request)
{
    empModel::create($request->all());

    return redirect()->route('staffdetails')->with('success', 'Data saved successfully!');
}
}
