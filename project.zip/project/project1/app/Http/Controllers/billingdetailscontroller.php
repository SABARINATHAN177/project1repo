<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use App\Models\BillModel;

class BillingDetailsController extends Controller
{
    public function index()
    {
        // Initialize an empty collection to avoid displaying data initially
        $billingRecords = collect(); 
        return view('billingdetails', compact('billingRecords'));
    }
    
    public function show(Request $request)
    {
        // Retrieve form input values
        $from_date = $request->input('from_date');
        $to_date = $request->input('to_date');
        $staffName = $request->input('StaffName');
    
        // Fetch data only if dates are provided
        if ($from_date && $to_date) {
            $billingRecords = BillModel::whereBetween('Date', [$from_date, $to_date])
                ->where('StaffName', $staffName)
                ->get();
        } else {
            $billingRecords = collect(); // Empty collection before form submission
        }
    
        return view('billingdetails', compact('billingRecords', 'from_date', 'to_date', 'staffName'));
    }
    
    

}
