<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class LoginController extends Controller
{
    public function index()
    {
        return view('login');
    }

    public function authenticate(Request $request)
    {
        $request->validate([
            'user_id' => 'required|string',
            'password' => 'required|string',
        ]);

        if ($request->user_id === 'Abc123' && $request->password === 'A@123') {
            return redirect()->route('dashboard.index')->with('success', 'Login successful!');
        }

        //return redirect()->route('login')->with('error', 'Invalid credentials.');
    } public function logout()
    {
        Auth::logout();
        return redirect('window.close')->with('success', 'You have logged out successfully!');
    }

}