<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\StockModel;
use Illuminate\Support\Facades\Log;

class StockdetailsController extends Controller
{
    // Retrieve all stock records
    public function index()
    {
        $stockRecords = StockModel::all();
        return view('stockdetails', compact('stockRecords'));
    }

    // Store new stock data

    public function store(Request $request)
    {
        stockModel::create($request->all());
    
        return redirect()->route('stockdetails')->with('success', 'Data saved successfully!');
    }}
   /* $request->validate([
        'updated_date' => 'required|date',
        'scissors' => 'required|integer|min:0',
        'razors' => 'required|integer|min:0',
        'clippers' => 'required|integer|min:0',
        'trimmers' => 'required|integer|min:0',
        'hairdryers' => 'required|integer|min:0',
        'curlingirons' => 'required|integer|min:0',
        'straighteners' => 'required|integer|min:0',
        'hotrollers' => 'required|integer|min:0',
        'facialsteamers' => 'required|integer|min:0',
        'ledtherapydevices' => 'required|integer|min:0',
        'microdermabrasionmachines' => 'required|integer|min:0',
        'nailclippers' => 'required|integer|min:0',
        'cuticlepushers' => 'required|integer|min:0',
        'nailbuffers' => 'required|integer|min:0',
        'uvlamps' => 'required|integer|min:0',
        'stylingchairs' => 'required|integer|min:0',
        'shampoostations' => 'required|integer|min:0',
        'massagebeds' => 'required|integer|min:0',
        'facialtissues' => 'required|integer|min:0'
    ]);

    $stock = StockModel::create($request->all());

    dd($stock); // Debug: Check if data is saved



        return redirect()->route('stockdetails')->with('success', 'Stock data saved successfully!');
  } */