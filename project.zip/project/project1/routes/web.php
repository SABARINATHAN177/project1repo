<?php
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\BillingDetailsController;
use App\Http\Controllers\BillingPageController;
use App\Http\Controllers\StockInfoController;
use App\Http\Controllers\StockdetailsController;
use App\Http\Controllers\StaffDataController;
use App\Http\Controllers\StaffDetailsController;
use App\Http\Controllers\LoginController;
use App\Http\Controllers\DashboardController;

// Home Page
//Route::get('/', function () {
    //return view('welcome');
//});

// Login Routes
Route::get('/', [LoginController::class, 'index'])->name('login');
Route::post('/login/authenticate', [LoginController::class, 'authenticate']);
Route::get('/logout', [LoginController::class, 'logout'])->name('logout');
// Dashboard Route
Route::get('/dashboard.index', [DashboardController::class, 'index'])->name('dashboard.index');

Route::get('/stockdetails', [StockdetailsController::class, 'index'])->name('stockdetails');
Route::post('/stockdetails/store', [StockdetailsController::class, 'store'])->name('stockdetails.store');

// Add these routes:
//Route::get('/stockinfo', [StockInfoController::class, 'index'])->name('stockinfo');
//Route::post('/stockinfo', [StockInfoController::class, 'store'])->name('stockinfo.store');'



Route::get('/stockinfo', [StockInfoController::class, 'index'])->name('stockinfo');
Route::post('/stockinfo', [StockInfoController::class, 'show'])->name('stockinfo.show');
// Handle form submission to fetch stock data
//Route::post('/stockinfo', [StockInfoController::class, 'show']);



//Route::get('/billingpage', [BillingPageController::class, 'index'])->name('billingpage');
//Route::post('/billingpage', [BillingPageController::class, 'store'])->name('billingpage.store');
Route::get('/billingpage', [BillingPageController::class, 'index'])->name('billingpage');
Route::post('/billingpage', [BillingPageController::class, 'store'])->name('billingpage.store');

Route::get('/billingdetails', [BillingDetailsController::class, 'index'])->name('billingdetails');
//Route::post('/billingdetails', [BillingDetailsController::class, 'store'])->name('billingdetails.store');
//Route::post('/billingdetails', [BillingDetailsController::class, 'show'])->name('billingdetails');
Route::post('/billingdetails', [BillingDetailsController::class, 'show'])->name('billingdetails.show');

Route::get('/staffdetails', [StaffDetailsController::class, 'index'])->name('staffdetails');
Route::post('/staffdetails', [StaffdetailsController::class, 'store'])->name('staffdetails.store');
//Route::post('/staffdetails', [StaffDetailsController::class, 'store'])->name('staffdetails.store');
//Route::post('/staffdetails', [StaffDetailsController::class, 'store'])->name('staffdetails.store');


Route::get('/staffdata', [StaffDataController::class, 'index'])->name('staffdata');
Route::post('/staffdata', [StaffDataController::class, 'show'])->name('staffdata.show');
//Route::POST('/staffdata', [StaffDataController::class, 'show'])->name('staffdata');
//Route::get('/staffdetails/edit/{id}', [StaffdetailsController::class, 'edit'])->name('staffdetails.edit');



// Billing Page Routes
//Route::get('/billing-page', [BillingPageController::class, 'index'])->name('billing.page');
//Route::post('/billing-page/store', [BillingPageController::class, 'store'])->name('billing.page.store');

// Billing Details Routes
//Route::get('/billing-details', [BillDetailsController::class, 'index'])->name('billing.details');

// Stock Info Routes
//Route::get('/stock-info', [StockInfoController::class, 'index'])->name('stock.info');

// Stock Details Routes
//Route::get('/stock-details', [StockDetailsController::class, 'index'])->name('stock.details');
//Route::post('/stock-details/store', [StockDetailsController::class, 'store'])->name('stock.details.store');

// Staff Data Routes
//Route::get('/staff-data', [StaffDataController::class, 'index'])->name('staff.data');

// Staff Details Routes
//Route::get('/staff-details', [StaffDetailsController::class, 'index'])->name('staff.details');
//Route::post('/staff-details/store', [StaffDetailsController::class, 'store'])->name('staff.details.store');