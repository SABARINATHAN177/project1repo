<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stock Informations | My Saloon Shop</title>
    <link rel="stylesheet" href="{{ asset('css/app.css') }}">
    <style>
        body { font-family: Arial, sans-serif; background-color: #f4f4f4; padding: 20px; }
        .form-container {width:800px;height:600px;margin-top:40px;margin-left:400px; background: white; padding: 20px; border-radius: 10px; box-shadow: 0 0 10px gray; }
        .form-title { text-align: center; font-size: 24px; font-weight: normal; margin-bottom: 15px; }
        .form-row { display: flex; justify-content: space-between; margin-bottom: 15px; }
        .form-group { width: 48%; }
        display: flex; /* Uses Flexbox to align elements */
    align-items: center; /* Ensures vertical alignment */

        label { font-weight: normal; display: block; margin-bottom: 5px; }
        input, select { width: 90%; padding: 8px; border-radius: 5px; border: 1px solid #ccc; }
    </style>
</head>
<body>
@include('sidebar')

<style>
    body {
        background: none; /* Removes the background */
        background-color: #f4f4f4; /* Set a solid color if needed */
    }
    

</style>

<form action="{{ route('stockinfo.show') }}" method="POST">
        @csrf
        <div class="form-container">
        <div class="form-title">Stock Records</div>
        <div class="form-row">
            <div class="form-group">
                
                <label for="date"style="position: absolute; top: 130px; margin-left:1px;">Select Date:</label>
                <input type="date" id="date" name="date" value="{{ old('date', $date ?? '') }}" style="margin-top:30px;" required>
                <button type="submit" style="position: absolute; top: 153px; margin-left:20px; color:;background:#008000; color: white; width:60px; padding: 6px;">View</button>

            </div>
        </div>
    

   
        @if(isset($stock))
   
        <br><br><div class="form-title">Stock Informations for {{ $date }}</div><br>
     
        <label><strong>Hair Cutting Tools:</strong></label>
        <div class="form-row">
            <div class="form-group">
                <label for="Scissors">Scissors:</label>
                <input type="number" id="scissors" name="scissors" value="{{ $stock->scissors ?? 'N/A' }}" required style="width:70px;padding:10px;">
            </div>
            <div class="form-group">
                <label for="razors">Razors:</label>
                <input type="number" id="razors" name="razors" value="{{ $stock->razors ?? 'N/A' }}" required style="width:70px;padding:10px;">
            </div>
            <div class="form-group">
                <label for="clippers">Clippers:</label>
                <input type="number" id="clippers" name="clippers" value="{{ $stock->clippers ?? 'N/A' }}" required style="width:70px;padding:10px;">
            </div>
            <div class="form-group">
                <label for="trimmers">Trimmers:</label>
                <input type="number" id="trimmers" name="trimmers" value="{{ $stock->trimmers ?? 'N/A' }}" required style="width:70px;padding:10px;">
            </div>
        </div>

        <label><strong>Styling Equipment:</strong></label>
        <div class="form-row">
            <div class="form-group">
                <label for="Hair dryers">Hairdryers:</label>
                <input type="number" id="hairdryers" name="hairdryers" value="{{ $stock->hairdryers ?? 'N/A' }}" required style="width:60px;padding:10px;">
            </div>
            <div class="form-group">
                <label for="curling irons">Curling Irons:</label>
                <input type="number" id="curlingirons" name="curlingirons" value="{{ $stock->curlingirons ?? 'N/A' }}" required style="width:60px;padding:10px;">
            </div>
            <div class="form-group">
                <label for="straighteners">Straighteners:</label>
                <input type="number" id="straighteners" name="straighteners" value="{{ $stock->straighteners ?? 'N/A' }}" required style="width:60px;padding:10px;">
            </div>
            <div class="form-group">
                <label for="hot rollers">Hot Rollers:</label>
                <input type="number" id="hotrollers" name="hotrollers" value="{{ $stock->hotrollers ?? 'N/A' }}" required style="width:60px;padding:10px;">
            </div>
        </div>

        <label><strong>Skin Care Devices:</strong></label>
        <div class="form-row">
            <div class="form-group">
                <label for="Facial steamers">FacialSteamers:</label>
                <input type="number" id="facialsteamers" name="facialsteamers" value="{{ $stock->facialsteamers ?? 'N/A' }}" required style="width:50px;padding:10px;">
            </div>
            <div class="form-group">
                <label for="LED therapy devices" style="left:90px;">LEDTherapyDevices:</label>
                <input type="number" id="ledtherapydevices" name="ledtherapydevices" value="{{ $stock->ledtherapydevices ?? 'N/A' }}" required style="width:50px;padding:10px;">
            </div>
            <div class="form-group">
                <label for="Microdermabrasion machines">MicrodermaMachines:</label>
                <input type="number" id="microdermabrasionmachines" name="microdermabrasionmachines" value="{{ $stock->microdermabrasionmachines ?? 'N/A' }}" required style="width:50px;padding:10px;">
            </div>
        
    </div><label><strong> Manicure&PedicureTools:</strong></label>
        <div class="form-row">
            <div class="form-group">
                <label for="Nailclippers">Nailclippers:</label>
                <input type="number" id="nailclippers" name="nailclippers" value="{{ $stock->nailclippers ?? 'N/A' }}" required style="width:60px;padding:10px;">
            </div>
            <div class="form-group">
                <label for="cuticlepushers">cuticlepushers:</label>
                <input type="number" id="cuticlepushers" name="cuticlepushers" value="{{ $stock->cuticlepushers ?? 'N/A' }}" required style="width:60px;padding:10px;">
            </div>
            <div class="form-group">
                <label for="nailbuffers">Nailbuffers:</label>
                <input type="number" id="nailbuffers" name="nailbuffers" value="{{ $stock->nailbuffers ?? 'N/A' }}" required style="width:60px;padding:10px;">
            </div>
            <div class="form-group">
                <label for="UVlamps">UVlamps:</label>
                <input type="number" id="uvlamps" name="uvlamps" value="{{ $stock->uvlamps ?? 'N/A' }}" required style="width:60px;padding:10px;">
            </div>
        </div>
        <label><strong>Salontools:</strong></label>
        <div class="form-row">
            <div class="form-group">
                <label for="Styling chairs">stylingchairs:</label>
                <input type="number" id="stylingchairs" name="stylingchairs" value="{{ $stock->stylingchairs ?? 'N/A' }}" required style="width:60px;padding:10px;">
            </div>
            <div class="form-group">
                <label for="shampoo stations">Shampoos:</label>
                <input type="number" id="shampoostations" name="shampoostations" value="{{ $stock->shampoostations ?? 'N/A' }}" required style="width:50px;padding:10px;">
            </div>
            <div class="form-group">
                <label for="massagebeds">Massagebeds:</label>
                <input type="number" id="massagebeds" name="massagebeds" value="{{ $stock->massagebeds ?? 'N/A' }}" required style="width:60px;padding:10px;">
            </div>
            <div class="form-group">
                <label for="facialtissues">Facialtissues:</label>
                <input type="number" id="facialtissues" name="facialtissues" value="{{ $stock->facialtissues ?? 'N/A' }}" required style="width:60px;padding:10px;">
            </div>
        </div>
      
        
        

    @endif
</div>
        


  <!-- Main Content -->
 
        </form>
        </body>
</html>
