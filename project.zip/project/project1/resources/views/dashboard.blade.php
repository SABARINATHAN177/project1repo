<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Saloon Shop</title>
    <link rel="stylesheet" href="{{ asset('css/app.css') }}">

    <style>
        body {
            font-family: Arial, sans-serif;
            background-image: url('{{ asset('images/sal.jpg') }}');
            background-size: cover;
            margin: 0;
            padding: 0;
            display: flex;
        }

        .sidebar {
            width: 250px;
            background: #333;
            color: white;
            padding: 20px;
            height: 100vh;
            position: fixed;
            left: 0;
            top: 0;
            overflow-y: auto;
        }

        .sidebar a {
            display: block;
            color: white;
            padding: 10px;
            text-decoration: none;
        }

        .sidebar a:hover {
            background: #555;
        }

        .main-content {
            margin-left: 270px;
            padding: 20px;
            flex-grow: 1;
            text-align: center;
        }
        .shop-name {
        font-size: 60px;
        margin-bottom: 10px;

        color: white;
    }
    .shop-address {
        font-size: 30px;
        color: white;
    }
    </style>
</head>
<body>


    <!-- Sidebar (Fixed Dashboard) -->
    <div class="sidebar">
        
        <a href="{{ route('dashboard.index') }}">Dashboard</a>
        <a href="{{ route('billingpage') }}">Billing Page</a>

        <a href="{{ route('stockdetails') }}">Stock Page</a>
        <a href="{{ route('staffdetails') }}"> Staff Page </a>
        <a href="{{ route('billingdetails') }}">Billing Records</a>

        <a href="{{ route('stockinfo') }}">Stock Records</a>
        <a href="{{ route('staffdata') }}">Staff Records</a>
        <a href="{{ route('logout') }}">Logout</a>
    </div>

    
</body>
</html>
  
    <!-- Main Content -->
    <div class="main-content">
        <div class="shop-name">My Saloon Shop</div>
        <br><div class="shop-address">ABC Nagar, Opp to DEF Bakery, Chennai</div>
    

</body>
</html>
