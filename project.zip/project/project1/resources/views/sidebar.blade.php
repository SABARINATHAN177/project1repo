<div class="sidebar">
   
<a href="{{ route('dashboard.index') }}">Dashboard</a>
        <a href="{{ route('billingpage') }}">Billing Page</a>

        <a href="{{ route('stockdetails') }}">Stock Page</a>
        <a href="{{ route('staffdetails') }}"> Staff Page </a>
        <a href="{{ route('billingdetails') }}">Billing Records</a>

        <a href="{{ route('stockinfo') }}">Stock Records</a>
        <a href="{{ route('staffdata') }}">Staff Records</a>
        <a href="{{ route('logout') }}">Logout</a>
    </div>
</div>

<style>
    body {z
        display: flex;
        margin: 0;
        font-family: Arial, sans-serif;
        background-image: url('{{ asset('images/picture1.jpg') }}');
        background-size: cover;
    }

    .sidebar {
        width: 250px;
        background: #333;
        color: white;
        padding: 20px;
        height: 100vh;
        position: fixed;
        left: 0;
        top: 0;
        overflow-y: auto;
    }

    .sidebar a {
        display: block;
        color: white;
        padding: 10px;
        text-decoration: none;
    }

    .sidebar a:hover {
        background: #555;
    }

    .main-content {
        margin-left: 270px;
        padding: 20px;
        flex-grow: 1;
        width: 100%;
    }
</style>