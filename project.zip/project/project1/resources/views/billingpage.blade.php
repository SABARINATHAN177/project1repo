<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Staff Details | My Saloon Shop</title>
    <link rel="stylesheet" href="{{ asset('css/app.css') }}">
    <style>
        body { font-family: Arial, sans-serif; background-color: #f4f4f4; padding: 20px; }
        .form-container { max-width:400px;height:680px; margin-left:600px; background: white; padding: 20px; border-radius: 10px; box-shadow: 0 0 10px gray; }
        .form-title { text-align: center; font-size: 24px; font-weight: bold; margin-bottom: 15px; }
        .form-row {display: flex; justify-content: space-between; margin-bottom: 15px; }
        .form-group {  margin-top:2%;width: 90%; }
        label { font-weight: normal; display: block; margin-bottom: 5px; }
 
        
        input, select { width: 90%; padding: 8px; border-radius: 5px; border: 1px solid #ccc; }
 .shop-name {
            font-size: 20px;
font-weight: bold;
text-align:center;

            margin-bottom: 10px;
            color: #222;
        }
        .shop-address {
text-align:center;
            font-size: 10px;
            color: #555;
        }
.container {
  height: 200px;
  position: relative;
  border: 3px;
}

.center {
  margin: 0;
  position: absolute;
  top: 24%;
  left: 80%;
  -ms-transform: translate(-50%, -50%);
  transform: translate(-230%, 40%);
}
 .box {     
            margin: 25px;
   height: 495px;
width:320px;
    margin-top: 40px; /* Moves the box 20px upwards */
      margin-bottom: 5px;
            padding: 20px;
            border: 3px solid black; /* Creates a black border */
           
            
        }



</style>
</head>
<body>@include('sidebar')

<style>
    body {
        background: none; /* Removes the background */
        background-color: #f4f4f4; /* Set a solid color if needed */
    }
</style>


          <div class="form-container">
        <div class="form-title">Billing Page</div><br>
        @if(session('success'))
    <div class="alert alert-success"style=" text-align:center;color: green;font-weight: bold;">
        {{ session('success') }}
    </div>
@endif
 <div class="box">
        <div class="shop-name">My Saloon Shop</div>
        <div class="shop-address">ABC Nagar, Opp to DEF Bakery, Chennai</div>
  
        <form action="{{ route('billingpage.store') }}" method="POST">
       @csrf
       <div class="form-row">
       
                <div class="form-group">
                    <label for="StaffName">StaffName:</label>
                    <select id="StaffName" name="StaffName">
                    <option value=""></option>
                        <option value="A">A</option>
                        <option value="B">B</option>
                        <option value="C">C</option>
                    </select>
                </div></div>
                  <div class="form-row">
                <div class="form-group">
                    <label for="ServiceName">ServiceName:</label>
                    <select id="ServiceName" name="ServiceName" required>
                    <option value=""></option>
                    <option value="Service1">Service1</option>
    <option value="Service2">Service2</option>
    <option value="Service3">Service3</option>
</select>

                </div></div>
                <div class="form-row">
    <div class="form-group">
        <label for="Amount">Amount:</label>
        <input type="number" id="Amount" name="Amount" required>
    </div></div>
                   
                 <div class="form-row">
    <div class="form-group">
        <label for="date">date:</label>
        <input type="date" id="date" name="date" required>
    </div></div>
<div class="form-row">
    <div class="form-group">
        <label for="time">time:</label>
        <input type="time" id="time" name="time" required>
    </div><div>
  

<div class="container">
  		<div class="center">
            		<button type="Print" style="margin-top: 15px; width:90px; padding: 10px;background: #333; color: white; border: none; border-radius: 5px; ">Print</button>
		</div>
        
</div>

</div>
