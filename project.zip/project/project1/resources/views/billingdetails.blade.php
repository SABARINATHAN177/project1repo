<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Billing Information | My Saloon Shop</title>
    <link rel="stylesheet" href="{{ asset('css/app.css') }}">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            padding: 20px;
        }
        .form-container {
            max-width: 890px;
            height: auto;
            margin: auto;
            margin-left:400px;
            left:750px;
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px gray;
        }
        .form-title {
            text-align: center;
            font-size: 24px;
            font-weight:normal;
            margin-bottom: 15px;
        }
        .form-row {
            display: flex;
            align-items: center;
            gap: 20px;
            margin-bottom: 15px;
        }
        .form-group {
            display: flex;
            align-items: center;
        }
        label {
            font-weight: normal;
            margin-right: 10px;
        }
        input, select {
            width: 150px;
            padding: 8px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }
        .button-group {
            display: flex;
            justify-content: center;
            gap: 10px;
            margin-top: 6px;
        }
        .btn {
            width: 90px;
            padding: 10px;
            top:10px;
            border: none;
            border-radius: 4px;
            color: white;
            cursor: pointer;
        }
        .btn-view {
            background-color: #008000;
            top:12px;
        }
    
        .table-container {
            overflow-x: auto;
            max-width: 100%;
            margin-top: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            border: 1px solid #ccc;
            padding: 10px;
            text-align: left;
        }
        th {
            background-color: #f0f0f0;
        }
        tfoot td {
            font-weight: normal;
        }
    </style>
</head>
<body>
@include('sidebar')

<style>
    body {
        background: none; /* Removes the background */
        background-color: #f4f4f4; /* Set a solid color if needed */
    }
</style>

    <div class="form-container">
        <div class="form-title">Billing Records</div>

        <form action="{{ route('billingdetails') }}" method="POST">
           @csrf

            <div class="form-row">
                <div class="form-group">
                    <label for="from_date">From Date:</label>
                    <input type="date" id="from_date" name="from_date">
                </div>

                <div class="form-group">
                    <label for="to_date">To Date:</label>
                    <input type="date" id="to_date" name="to_date">
                </div>

                <div class="form-group">
                    <label for="StaffName">Staff Name:</label>
                    <select id="StaffName" name="StaffName">
                        <option value=""></option>                        <option value="A">A</option>
                        <option value="B">B</option>
                        <option value="C">C</option>
                    </select>
                </div>

                <div class="button-group">
                    <button type="submit"  style='top:10px;'class="btn btn-view">View</button>
                </div>
            </div>
        </form>


        <!-- Billing Details Table -->
        @if(isset($billingRecords) && $billingRecords->isNotEmpty())
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>S.No</th>
                    <th>Date</th>
                    <th>Service Name</th>
                    <th>Amount</th>
                </tr>
            </thead>
            <tbody>
                @php
                    $totalAmount = 0; // Initialize total amount
                @endphp

                @foreach($billingRecords as $record)
                    <tr>
                        <td>{{ $loop->iteration }}</td>
                        <td>{{ $record->Date }}</td>
                        <td>{{ $record->ServiceName }}</td>
                        <td>{{ $record->Amount }}</td>
                    </tr>
                    @php
                        $totalAmount += $record->Amount; // Summing up the Amount column
                    @endphp
                @endforeach
            </tbody>
            <tfoot>
                <tr>
                    <td colspan="3" style="text-align:right;"><strong>Total:</strong></td>
                    <td><strong>₹{{ number_format($totalAmount, 2) }}</strong></td>
                </tr>
            </tfoot>
        </table>
    </div>
@endif

</body>
</html>