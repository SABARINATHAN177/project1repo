<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login | My Saloon Shop</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <style>
        body { font-family: Arial, sans-serif; background-color: #f4f4f4; }
        .login-container { width: 300px; margin: 100px auto; padding: 20px; background: white; border-radius: 5px; box-shadow: 0 0 10px gray; }
        .login-container h2 { text-align: center; margin-bottom: 20px; }
        label { font-weight: bold; margin-bottom: 5px; }
        input { width: 90%; padding: 10px; border: 1px solid #ccc; border-radius: 5px; }
        .form-group { margin-bottom: 15px; }
        .btn { width: 100%; padding: 10px; background: #333; color: white; border: none; cursor: pointer; }
        .btn:hover { background: #555; }
    </style>
<body>

    <div class="login-container">
        <h2>Login</h2>
        <!--<form method="POST" action="<?php echo e(route('login')); ?>">-->
        <form method="POST" action="<?php echo e(url('/login/authenticate')); ?>">
            <?php echo csrf_field(); ?>   
            <?php if(session('error')): ?>
            <div style="color: red; text-align: center; margin-bottom: 10px;">
                <?php echo e(session('error')); ?>

            </div>
            <?php endif; ?>

            <?php if(session('success')): ?>
                <div style="color: green; text-align: center; margin-bottom: 10px;">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>        
            <div class="form-group">
                <label>User Id</label>
                <input type="text" name="user_id" id="ABC" required class="form-control">
            </div>
            <div class="form-group">
                <label>Password</label>
                <input type="password" name="password" id="123" required class="form-control">
            </div>
            <button type="submit" class="btn">Login</button>
        </form>
    </div>

</body>
</html>
<?php /**PATH C:\Laravel\project1\resources\views/login.blade.php ENDPATH**/ ?>