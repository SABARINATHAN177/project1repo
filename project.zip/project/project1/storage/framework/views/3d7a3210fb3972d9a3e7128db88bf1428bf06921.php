<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Staff Data | My Saloon Shop</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <style>
        body { font-family: Arial, sans-serif; background-color: #f4f4f4; padding: 20px; }
        .form-container { width:700px;height:600px;  margin-top:30px;margin-left:400px; background: white; padding: 20px; border-radius: 10px; box-shadow: 0 0 10px gray; }
        .form-title { text-align: center; font-size: 24px; font-weight: normal; margin-bottom: 15px; }
        .form-row { display: flex; justify-content: space-between; margin-bottom: 15px; }
        .form-group { width: 48%; }
        label { font-weight: normal; display: block; margin-bottom: 5px; }
        input, select { width: 90%; padding: 8px; border-radius: 5px; border: 1px solid #ccc;
            <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">

             }
    </style>
</head>
<body>
    <?php echo $__env->make('sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <style>
    body {
        background: none; /* Removes the background */
        background-color: #f4f4f4; /* Set a solid color if needed */
    }
    
    .Stock-info {
        font-size: 30px;
       margin-top:-650px;
        color: #222; margin-left:480px;}
    <style>
        .box {
            width: 320px;
            height: 500px;
            padding: 20px;
            border: 3px solid black;
        
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
        }
    </style>



</style>
        <form action="<?php echo e(route('staffdata.show')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="container">

            <div class="box">

            <div class="form-container">
            <div class="form-title">Staff Records</div>
            <div class="form-row">
                <div style="display: flex; align-items: center; gap: 10px;">
                    <label for="StaffName">Staff name:</label>
                    <input type="text" id="StaffName" name="StaffName" required value="<?php echo e(old('StaffName')); ?>">
                    <button type="submit" style="position: absolute; top: 110x; margin-left:285px; color:;background:#008000; color: white; width:60px; padding: 6px;">View</button>
                    </div>
            </div>
        
        <?php if(isset($staff)): ?>
        
    
      
            <div class="form-row">
                <div class="form-group">
                    <label for="name">Name:</label>
                    <input type="text" id="name" name="Name" value="<?php echo e($staff->Name ?? ''); ?>" required>
                </div>
                <div class="form-group">
                    <label for="age">Age:</label>
                    <input type="number" id="age" name="Age" value="<?php echo e($staff->Age ?? ''); ?>" required>
                </div>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label for="gender">Gender:</label>
                    <select id="gender" name="Gender">
                        <option value="Male" <?php echo e(isset($staff) && $staff->Gender == 'Male' ? 'selected' : ''); ?>>Male</option>
                        <option value="Female" <?php echo e(isset($staff) && $staff->Gender == 'Female' ? 'selected' : ''); ?>>Female</option>
                        <option value="Others" <?php echo e(isset($staff) && $staff->Gender == 'Others' ? 'selected' : ''); ?>>Others</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="Experience">Experience:</label>
                    <input type="text" id="Experience" name="Experience" value="<?php echo e($staff->Experience ?? ''); ?>" required>
                </div>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label for="contact">Contact No:</label>
                    <input type="text" id="contact" name="ContactNo" value="<?php echo e($staff->ContactNo ?? ''); ?>" required>
                </div>
                <div class="form-group">
                    <label for="email">Email-Id:</label>
                    <input type="email" id="email" name="EmailId" value="<?php echo e($staff->EmailId ?? ''); ?>" required>
                </div>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label for="qualification">Qualification:</label>
                    <input type="text" id="qualification" name="Qualification" value="<?php echo e($staff->Qualification ?? ''); ?>" required>
                </div>
                <div class="form-group">
                    <label for="marital_status">Marital Status:</label>
                    <select id="marital_status" name="MaritalStatus">
                        <option value="yes" <?php echo e(isset($staff) && $staff->MaritalStatus == 'yes' ? 'selected' : ''); ?>>Yes</option>
                        <option value="No" <?php echo e(isset($staff) && $staff->MaritalStatus == 'No' ? 'selected' : ''); ?>>No</option>
                    </select>
                </div>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label for="address1">Address Line 1:</label>
                    <input type="text" id="address1" name="Address" value="<?php echo e($staff->Address ?? ''); ?>" required>
                </div>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label for="city">City:</label>
                    <input type="text" id="city" name="City" value="<?php echo e($staff->City ?? ''); ?>" required>
                </div>
                <div class="form-group">
                    <label for="state">State:</label>
                    <input type="text" id="state" name="State" value="<?php echo e($staff->State ?? ''); ?>" required>
                </div>
                <div class="form-group">
                    <label for="Pincode">Pincode:</label>
                    <input type="number" id="Pincode" name="Pincode" value="<?php echo e($staff->Pincode ?? ''); ?>" required>
                </div>
            </div>
            </div>
        <?php endif; ?>
    </div></form>
</body>
</html><?php /**PATH C:\Laravel\project1\resources\views/staffdata.blade.php ENDPATH**/ ?>