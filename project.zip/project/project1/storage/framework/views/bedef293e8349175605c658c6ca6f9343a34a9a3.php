<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stock Details | My Saloon Shop</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <style>
        body { font-family: Arial, sans-serif; background-color: #f4f4f4; padding: 20px; }
        .form-container { max-width:900px;height:680px; margin-left:400px; background: white; padding: 20px; border-radius: 10px; box-shadow: 0 0 10px gray; }
        .form-title { text-align: center; font-size: 24px; font-weight: bold; margin-bottom: 15px; }
        .form-row { display: flex; justify-content: space-between; margin-bottom: 15px; }
        .form-group {
    display: flex; /* Uses Flexbox to align elements */
    align-items: center; /* Ensures vertical alignment */
}
label {
    margin-right: 10px;

}
        label { font-weight: normal; margin-bottom: 5px; }
        input, select { width: 90%; padding: 8px; border-radius: 5px; border: 1px solid #ccc; }
       <style>
.container {
  height: 200px;
  position: relative;
  border: 3px solid green;
}

.center {
  margin: 0;
  position: absolute;
  top: 93%;
  left:57%;
  -ms-transform: translate(-50%, -50%);
  transform: translate(-50%, -50%);
}
</style>
</head>
<body>
<?php echo $__env->make('sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<style>
    body {
        background: none; /* Removes the background */
        background-color: #f4f4f4; /* Set a solid color if needed */
    }
   
</style>




    <div class="form-container">
        <div class="form-title">Stock page</div>
          
        <form action="<?php echo e(route('stockdetails.store')); ?>" method="POST">
                 <?php echo csrf_field(); ?> 
                 
<div class="form-group">
        <label for="date">UpdatedDate:</label>
        <input type="date" id="updated_date" name="updated_date" required style="width:100px; padding:10px;">
    </div>
    <?php if(session('success')): ?>
    <div class="alert alert-success"style="color: green;font-weight: bold;text-align: center; margin-right: 10px; margin-top: 10px;">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>
<br><br><label for="Hair Cutting Tools:"><strong>HairCutting Tools:</label> <br><br>

 <div class="form-row">
                <div class="form-group">
                     
                    <label for="Scissors">Scissors:</label>
                    <input type="number" id="scissors" name="scissors" required style="width:70px;padding:10px;">
                </div>
                 
                <div class="form-group">
                    <label for="razors"> Razors:</label>
                    <input type="number" id="razors" name="razors" required style="width:70px;padding:10px; align-center;">
                </div>
                
                
                
                <div class="form-group">
                    <label for="clippers">Clippers:</label>
                    <input type="number" id="clippers" name="clippers" required style="width:70px;padding:10px; ">
                </div>
      
                <div class="form-group">
                    <label for="trimmers">Trimmers:</label>
                    <input type="number" id="trimmers" name="trimmers" required style="width:70px;padding:10px;">
                </div>
 <br><br></div><label for="StylingEquipment: "><strong>StylingEquipment: :</label><br><br>
<div class="form-row">

                 
                <div class="form-group">
                    <label for="Hair dryers"> Hairdryers:</label>
                    <input type="number" id="hairdryers" name="hairdryers" required style="width:60px;padding:10px; align-center;">
                </div>
                
                
                
                <div class="form-group">
                    <label for="curling irons"style="margin-left: 20px;"> Curlingirons:</label>
                    <input type="number" id="curlingirons" name="curlingirons" required style="width:60px;padding:10px; ">
                </div>
  
                <div class="form-group">
                    <label for="straighteners"style="margin-left: 20px;"> Straighteners:</label>
                    <input type="number" id="straighteners" name="straighteners" required style="width:60px;padding:10px;">
                </div>
                 
                <div class="form-group">
                    <label for="hot rollers"style="margin-left: 20px;"> Hotrollers:</label>
                    <input type="number" id="hotrollers" name="hotrollers" required style="width:60px;padding:10px; align-center;">
                </div>
                          
<br><br> </div><label for="StylingEquipment: "><strong> SkinCareDevices:</label><br><br>
<div class="form-row">

                 
                <div class="form-group">
                    <label for="Facialsteamers"style="margin-left: 20px;">  Facialsteamers:</label>
                    <input type="number" id="facialsteamers" name="facialsteamers" required style="width:90px;padding:10px; align-center;">
                </div>
                
                
              
  
                <div class="form-group">
                    <label for="LED therapy devices"style="margin-left: 20px;">LEDtherapydevices:</label><br><br>
                    <input type="number" id="ledtherapydevices" name="ledtherapydevices" required style="width:90px;padding:10px;">
                </div>
                   
                <div class="form-group">
                    <label for="microdermabrasionmachines"style="margin-left: 20px;">Microdermamachines:</label>
                    <input type="number" id="microdermabrasionmachines" name="microdermabrasionmachines" required style="width:90px;padding:10px; ">
                </div>
                                         
                <br><br></div><label for="StylingEquipment: "><strong> Manicure&PedicureTools:</label><br><br>

                <div class="form-row">

                 
                <div class="form-group">
                    <label for="Nailclippers"style="margin-left: 20px;">Nailclippers:</label>
                    <input type="number" id="nailclippers" name="nailclippers" required style="width:70px;padding:10px; align-center;">
                </div>
                
                
                
                <div class="form-group">
                    <label for="cuticlepushers"style="margin-left: 20px;">Cuticlepushers:</label>
                    <input type="number" id="cuticlepushers" name="cuticlepushers" required style="width:70px;padding:10px; ">
                </div>
  
                <div class="form-group">
                    <label for="nailbuffers"style="margin-left: 20px;">Nailbuffers:</label>
                    <input type="number" id="nailbuffers" name="nailbuffers" required style="width:70px;padding:10px;">
                </div>
                 
                <div class="form-group">
                    <label for="UVlamps "style="margin-left: 20px;"> UVlamps :</label>
                    <input type="number" id="uvlamps" name="uvlamps" required style="width:70px;padding:10px; align-center;">
                </div>

                <br><br>    </div><label for="StylingEquipment: "><strong> Salontools:</label><br><br>



              <div class="form-row">

                 
                <div class="form-group">
                    <label for="Styling chairs"style="margin-left: 20px;"> Stylingchairs:</label>
                    <input type="number" id="stylingchairs" name="stylingchairs" required style="width:60px;padding:10px; align-center;">
                </div>
                
                
                
                <div class="form-group">
                    <label for="shampoo stations"style="margin-left: 20px;">Shampoos:</label>
                    <input type="number" id="shampoostations" name="shampoostations" required style="width:60px;padding:10px; ">
                </div>
  
                <div class="form-group">
                    <label for="massage beds"style="margin-left: 20px;">Massagebeds:</label>
                    <input type="number" id="massagebeds" name="massagebeds" required style="width:60px;padding:10px;">
                </div>
                 
                <div class="form-group">
                    <label for="facial tissues"style="margin-left: 20px;"> Facialtissues:</label>
                    <input type="number" id="facialtissues" name="facialtissues" required style="width:60px;padding:10px; align-center;">
                </div>
                          </div>


 <div class="container">
  		<div class="center">
            		<button type="submit" style="margin-top: 19px; width:100px; padding: 10px;background: #333; color: white; border: none; border-radius: 5px; ">Save</button>
		</div>
	    </div>

<?php /**PATH C:\Laravel\project1\resources\views/stockdetails.blade.php ENDPATH**/ ?>