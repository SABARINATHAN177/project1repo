<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Staff Details | My Saloon Shop</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <style>
        body { font-family: Arial, sans-serif; background-color: #f4f4f4; padding: 20px; }
        .form-container { max-width:700px;height:650px; margin-left:500px; background: white; padding: 20px; border-radius: 10px; box-shadow: 0 0 10px gray; }
        .form-title { text-align: center; font-size: 24px; font-weight: bold; margin-bottom: 15px; }
        .form-row { display: flex; justify-content: space-between; margin-bottom: 15px; }
        .form-group { width: 48%; }
        label { font-weight: bold; display: block; margin-bottom: 5px; }
        input, select { width: 90%; padding: 8px; border-radius: 5px; border: 1px solid #ccc; }

.container {
  height: 200px;
  position: relative;

}

.center {
  margin: 0;
  position: absolute;
  top: 15%;
  left: 50%;
  -ms-transform: translate(-50%, -50%);
  transform: translate(-50%, -50%);
}
</style>
</head>
<body><?php echo $__env->make('sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<style>
    body {
        background: none; /* Removes the background */
        background-color: #f4f4f4; /* Set a solid color if needed */
    }
    
</style>


    <div class="form-container">
        <div class="form-title">Staff Page</div><br><br>
        <?php if(session('success')): ?>
    <div class="alert alert-success"style="color: green;font-weight: bold;text-align: center; margin-right: 10px; margin-top: 5px;">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>
        
        <br><br><form action="<?php echo e(route('staffdetails.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
                       <div class="form-row">
                <div class="form-group">
                    <label for="name">Name</label>
                    <input type="text" id="Name" name="Name">
                    </div>
                <div class="form-group">
                    <label for="age">Age:</label>
                    <input type="number" id="Age" name="Age">
                    </div>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label for="gender">Gender:</label>
                    <select id="Gender" name="Gender">
                    <option value=""></option>
                        <option value="Male">Male</option>
                        <option value="Female">Female</option>
                        <option value="Others">Others</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="Expereince">Experience:</label>
                    <input type="text" id="Experience" name="Experience">
                    </div>
                
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label for="contact">Contact No:</label>
                    <input type="text" id="ContactNo" name="ContactNo">
                    </div>
                <div class="form-group">
                    <label for="email">Email-Id:</label>
                    <input type="email" id="EmailId" name="EmailId"></div>
                    </div>

            <div class="form-row">
                <div class="form-group">
                    <label for="qualification">Qualification:</label>
                    <input type="text" id="Qualification" name="Qualification" required>
                </div>
                
                <div class="form-group">
                    <label for="Marital_status">Marital Status:</label>
                    <select id="MaritalStatus" name="MaritalStatus">
                    <option value=""></option>
                        <option value="yes">Yes</option>
                        <option value="no">No</option>
                    </select>
                </div>
            </div>

           
            

            <div class="form-row">
                <div class="form-group">
                    <label for="address1">Address:</label>
                    <input type="text" id="Address" name="Address" required style="width:650px; padding:10px">

                </div>
                
            </div>
                <div class="form-row">
                <div class="form-group">
                    <label for="city">city:</label>
                    <input type="text" id="City" name="City" required style="width:200px;padding:10px;">
                </div>
                 
                <div class="form-group">
                    <label for="state">state:</label>
                    <input type="text" id="State" name="State" required style="width:200px;padding:10px; align-center;">
                </div>
                
                
                
                <div class="form-group">
                    <label for="Pincode">Pincode:</label>
                    <input type="number" id="Pincode" name="Pincode" required style="width:200px;padding:10px; ">
                </div>
            </div>

	    <div class="container">
  		<div class="center">
            		<button type="submit" style="margin-top: 15px; width:100px; padding: 10px;background: #333; color: white; border: none; border-radius: 5px; ">Submit</button>
		</div>
	    </div>
        </form>
    </div>

</body>
</html><?php /**PATH C:\Laravel\project1\resources\views/staffdetails.blade.php ENDPATH**/ ?>